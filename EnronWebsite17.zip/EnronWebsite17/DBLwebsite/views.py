from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def homepage(request):
    return render(request, "DBLwebsite/homepage.html")

def Vis1(request):
    return render(request, "DBLwebsite/vis1.html")

def Vis4(request):
    return render(request, "DBLwebsite/vis4.html")  