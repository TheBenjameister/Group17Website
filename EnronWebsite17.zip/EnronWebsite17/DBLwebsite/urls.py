from django.contrib import admin
from django.urls import path
from . import views
from DBLwebsite.Vis import EnronVis1
from DBLwebsite.Vis import Vis4

urlpatterns = [
    path('', views.homepage, name = "homepage"),
    path('Vis1', views.Vis1, name = "Vis1"),
    path('Vis4', views.Vis4, name = "Vis4")
]
